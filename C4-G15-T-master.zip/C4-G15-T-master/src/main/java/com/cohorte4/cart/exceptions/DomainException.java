package com.cohorte4.cart.exceptions;

public class DomainException extends RuntimeException{
}
