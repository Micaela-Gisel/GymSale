package com.cohorte4.cart.controllers;

public class Controller {
}
